# Color-Game
A color game to guess RGB values of a colors using vanilla JavaScript, HTML and CSS.
jatingupta.github.io
