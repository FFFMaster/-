import Canvas from './Canvas';

let gameCanvas;

window.onload = function () {
    gameCanvas = new Canvas('gameCanvas');
};
