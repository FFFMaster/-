export default {
    canvasBg: '#000000',
    ball: '#ffffff',
    paddle: '#ffffff',
    net: '#ffffff',
}
