# es6 Pong

My brief attempt at a basic pong remake using es6.

### Playing

open `public/index.html`

### Developing

`npm install`
`npm run watch`

*This was a weekend project and likely won't be developed further. Feel free to have fun with it!*
